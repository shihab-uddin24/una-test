<?php defined('BX_DOL') or die('hack attempt');
/**
 * Copyright (c) UNA, Inc - https://una.io
 * MIT License - https://opensource.org/licenses/MIT
 *
 * @defgroup    UnaTemplate UNA Template Classes
 * @{
 */

/**
 * @see BxDolCover
 */
class BxTemplCover extends BxBaseCover
{
    public function __construct ($oTemplate = false)
    {
        parent::__construct ($oTemplate);
    }
}

/** @} */
