<?php
/**
 * Copyright (c) UNA, Inc - https://una.io
 * MIT License - https://opensource.org/licenses/MIT
 *
 * @defgroup    UnaTemplate UNA Template Classes
 * @{
 */
defined('BX_DOL') or die('hack attempt');

class BxTemplAuditGrid extends BxBaseAuditGrid
{
    function __construct($sPage = '')
    {
        parent::__construct($sPage);
    }
}
/** @} */
