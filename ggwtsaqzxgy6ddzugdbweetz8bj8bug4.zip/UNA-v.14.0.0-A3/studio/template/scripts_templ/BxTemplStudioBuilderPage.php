<?php
/**
 * Copyright (c) UNA, Inc - https://una.io
 * MIT License - https://opensource.org/licenses/MIT
 *
 * @defgroup    UnaStudioView UNA Studio Representation classes
 * @ingroup     UnaStudio
 * @{
 */
defined('BX_DOL') or die('hack attempt');

class BxTemplStudioBuilderPage extends BxBaseStudioBuilderPage
{
    function __construct($sType = '', $sPage = '')
    {
        parent::__construct($sType, $sPage);
    }
}
/** @} */
