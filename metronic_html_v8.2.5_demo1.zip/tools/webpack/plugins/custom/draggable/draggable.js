// Draggable - a lightweight, responsive, modern drag & drop library: https://shopify.github.io/draggable/

import Draggable from '@shopify/draggable/build/umd';
window.Draggable = Draggable;