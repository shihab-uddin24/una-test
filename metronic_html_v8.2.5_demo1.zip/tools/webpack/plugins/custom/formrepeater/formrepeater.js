// Form Repeater - Creates an interface to add and remove a repeatable group of input elements: https://github.com/DubFriend/jquery.repeater
require('jquery.repeater');